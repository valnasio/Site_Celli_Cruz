/**
 * CELLI CRUZ - JavaScript Principal
 * Arquivo: js/main.js
 * Gerencia: carregamento de dados, interações globais, formulários, animações
 */

// ============================================================
// CONFIGURAÇÃO GLOBAL
// ============================================================

const CONFIG = {
  dataUrl: '../data/imoveis.json',
  whatsappMsg: encodeURIComponent('Olá! Tenho interesse em um imóvel da Celli Cruz. Podem me ajudar?')
};

// Detecta se está na raiz ou em /pages
const isInPages = window.location.pathname.includes('/pages/');
const dataPath = isInPages ? '../data/imoveis.json' : './data/imoveis.json';

// ============================================================
// CARREGAMENTO DE DADOS
// ============================================================

async function loadData() {
  try {
    const res = await fetch(dataPath);
    if (!res.ok) throw new Error('Erro ao carregar dados');
    return await res.json();
  } catch (e) {
    console.warn('Não foi possível carregar dados do JSON. Usando dados de fallback.');
    return null;
  }
}

// ============================================================
// HEADER / NAVBAR
// ============================================================

function initHeader() {
  const header = document.querySelector('.header');
  const menuToggle = document.querySelector('.menu-toggle');
  const nav = document.querySelector('.nav');

  if (!header) return;

  // Scroll effect
  window.addEventListener('scroll', () => {
    header.classList.toggle('scrolled', window.scrollY > 20);
  }, { passive: true });

  // Mobile menu
  if (menuToggle && nav) {
    menuToggle.addEventListener('click', () => {
      nav.classList.toggle('open');
    });
  }

  // Active link por página
  const path = window.location.pathname;
  document.querySelectorAll('.nav-link').forEach(link => {
    const href = link.getAttribute('href');
    if (href && (path.endsWith(href) || (path.endsWith('/') && href === 'index.html'))) {
      link.classList.add('active');
    }
  });
}

// ============================================================
// ANIMAÇÃO FADE-IN-UP (Intersection Observer)
// ============================================================

function initAnimations() {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });

  document.querySelectorAll('.fade-in-up').forEach((el, i) => {
    el.style.transitionDelay = `${i * 0.07}s`;
    observer.observe(el);
  });
}

// ============================================================
// WHATSAPP FLOAT
// ============================================================

function initWhatsApp() {
  const btn = document.querySelector('.whatsapp-btn');
  if (!btn) return;
  // O href é definido no HTML via config
}

// ============================================================
// TOAST / NOTIFICAÇÕES
// ============================================================

function showToast(msg, type = 'success') {
  let toast = document.getElementById('toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'toast';
    toast.className = 'toast';
    document.body.appendChild(toast);
  }
  toast.className = `toast ${type}`;
  toast.textContent = msg;
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 3500);
}

// ============================================================
// FORMULÁRIO DE CONTATO (Hero e CTA)
// ============================================================

function initForms() {
  document.querySelectorAll('.js-contact-form').forEach(form => {
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const btn = form.querySelector('button[type="submit"]');
      const original = btn.textContent;
      btn.textContent = 'Enviando...';
      btn.disabled = true;

      // Coleta dados
      const data = Object.fromEntries(new FormData(form));

      // Simula envio (substitua pelo seu endpoint real, ex: Formspree, EmailJS, etc.)
      await simulateEmailSend(data);

      btn.textContent = original;
      btn.disabled = false;
      form.reset();
      showToast('✅ Mensagem enviada! Entraremos em contato em breve.', 'success');
    });
  });
}

/**
 * simulateEmailSend - Substituir pela integração real
 * Opções: Formspree (formspree.io), EmailJS, backend PHP/Node
 *
 * Exemplo Formspree:
 * const res = await fetch('https://formspree.io/f/SEU_ID', {
 *   method: 'POST',
 *   headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
 *   body: JSON.stringify(data)
 * });
 */
async function simulateEmailSend(data) {
  console.log('📧 Formulário enviado:', data);
  await new Promise(r => setTimeout(r, 900)); // Simula delay
  return true;
}

// ============================================================
// RENDERIZAR CARDS DE IMÓVEIS (Home)
// ============================================================

function renderImoveisDestaque(imoveis, container) {
  if (!container) return;
  const destaques = imoveis.filter(i => i.destaque).slice(0, 3);
  container.innerHTML = destaques.map(imovel => criarCardImovel(imovel)).join('');
}

function criarCardImovel(imovel) {
  const badgeClass = imovel.status === 'Lançamento' ? 'badge-lancamento'
    : imovel.status === 'Em Obras' ? 'badge-obras' : 'badge-pronto';

  return `
    <div class="imovel-card fade-in-up" onclick="verImovel(${imovel.id})">
      <div class="imovel-card-img">
        <img src="${imovel.imagem}" alt="${imovel.nome}" loading="lazy">
        <span class="imovel-badge">${imovel.tag}</span>
      </div>
      <div class="imovel-card-body">
        <p class="imovel-cidade">${imovel.cidade}</p>
        <h3 class="imovel-nome">${imovel.nome}</h3>
        <div class="imovel-specs">
          <span class="spec">
            <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
              <path d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/>
            </svg>
            ${imovel.quartos} Quartos
          </span>
          <span class="spec">
            <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
              <rect x="3" y="3" width="18" height="18" rx="2"/>
            </svg>
            A partir de ${imovel.metragem} m²
          </span>
        </div>
        <div class="imovel-card-footer">
          <span class="imovel-bairro">
            <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
              <path d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/>
              <path d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/>
            </svg>
            ${imovel.bairro}
          </span>
          <span class="btn btn-primary" style="padding: 8px 16px; font-size: 13px;">Ver mais →</span>
        </div>
      </div>
    </div>
  `;
}

// Navega para a página do imóvel
function verImovel(id) {
  const isInPages = window.location.pathname.includes('/pages/');
  const base = isInPages ? '' : 'pages/';
  window.location.href = `${base}imovel-detalhe.html?id=${id}`;
}

// ============================================================
// DIFERENCIAIS DA HOME (dinâmico)
// ============================================================

const DIFERENCIAIS = [
  { icon: '🏊', label: 'Piscina Adulto e Infantil' },
  { icon: '🏋️', label: 'Academia Equipada' },
  { icon: '⚽', label: 'Quadra Poliesportiva' },
  { icon: '🧸', label: 'Brinquedoteca' },
  { icon: '🎉', label: 'Salão de Festas' },
  { icon: '🎮', label: 'Salão de Jogos' },
  { icon: '🍖', label: 'Espaço Gourmet' },
  { icon: '🛡️', label: 'Segurança 24h' },
];

function renderDiferenciais(container) {
  if (!container) return;
  container.innerHTML = DIFERENCIAIS.map(d => `
    <div class="dif-card fade-in-up">
      <div class="dif-icon">${d.icon}</div>
      <h4>${d.label}</h4>
    </div>
  `).join('');
}

// ============================================================
// INIT GLOBAL
// ============================================================

document.addEventListener('DOMContentLoaded', async () => {
  initHeader();
  initWhatsApp();
  initForms();

  // Carrega dados
  const dados = await loadData();

  // Home - vitrine destaques
  const vitrineGrid = document.getElementById('vitrine-imoveis');
  if (vitrineGrid && dados) {
    renderImoveisDestaque(dados.imoveis, vitrineGrid);
  }

  // Diferenciais
  const difGrid = document.getElementById('dif-grid');
  if (difGrid) renderDiferenciais(difGrid);

  // Config dinâmica (WhatsApp, telefone, etc.)
  if (dados) {
    const { config } = dados;
    document.querySelectorAll('.js-whatsapp').forEach(el => {
      el.href = `https://wa.me/${config.whatsapp}?text=${CONFIG.whatsappMsg}`;
    });
    document.querySelectorAll('.js-telefone').forEach(el => el.textContent = config.telefone);
    document.querySelectorAll('.js-email').forEach(el => el.textContent = config.email);
    document.querySelectorAll('.js-endereco').forEach(el => el.textContent = config.endereco);
  }

  // Inicia animações por último (após DOM pronto)
  setTimeout(initAnimations, 100);
});
