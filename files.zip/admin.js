/**
 * CELLI CRUZ - JavaScript Admin
 * Arquivo: js/admin.js
 * Gerencia: CRUD de imóveis, configurações, preview em tempo real
 *
 * NOTA: Este sistema usa JSON local para demonstração.
 * Para produção, implemente um backend (PHP/Node/Python) que
 * salve os dados no servidor/banco de dados.
 * Ver seção "INTEGRAÇÃO COM BACKEND" no final deste arquivo.
 */

// ============================================================
// ESTADO DA APLICAÇÃO
// ============================================================

let appData = { config: {}, imoveis: [] };
let editingId = null;

// ============================================================
// CARREGAR DADOS
// ============================================================

async function loadAdminData() {
  try {
    const res = await fetch('../data/imoveis.json?t=' + Date.now());
    appData = await res.json();
    renderDashboard();
    renderTable();
  } catch (e) {
    showAdminToast('Erro ao carregar dados. Verifique o arquivo JSON.', 'error');
  }
}

// ============================================================
// DASHBOARD - ESTATÍSTICAS
// ============================================================

function renderDashboard() {
  const total = appData.imoveis.length;
  const destaques = appData.imoveis.filter(i => i.destaque).length;
  const lancamentos = appData.imoveis.filter(i => i.status === 'Lançamento').length;
  const prontos = appData.imoveis.filter(i => i.status === 'Pronto para Morar').length;

  setEl('stat-total', total);
  setEl('stat-destaques', destaques);
  setEl('stat-lancamentos', lancamentos);
  setEl('stat-prontos', prontos);
}

function setEl(id, val) {
  const el = document.getElementById(id);
  if (el) el.textContent = val;
}

// ============================================================
// TABELA DE IMÓVEIS
// ============================================================

function renderTable(filter = '') {
  const tbody = document.getElementById('imoveis-tbody');
  if (!tbody) return;

  let lista = appData.imoveis;
  if (filter) {
    const f = filter.toLowerCase();
    lista = lista.filter(i =>
      i.nome.toLowerCase().includes(f) ||
      i.bairro.toLowerCase().includes(f) ||
      i.status.toLowerCase().includes(f)
    );
  }

  if (lista.length === 0) {
    tbody.innerHTML = `<tr><td colspan="7" style="text-align:center; padding: 40px; color: var(--cinza-texto);">Nenhum imóvel encontrado.</td></tr>`;
    return;
  }

  tbody.innerHTML = lista.map(imovel => `
    <tr>
      <td>${imovel.id}</td>
      <td><img src="${imovel.imagem}" class="imovel-thumb" alt="" onerror="this.src='https://via.placeholder.com/56x42?text=Sem+foto'"></td>
      <td>
        <strong>${imovel.nome}</strong><br>
        <span style="font-size: 12px; color: var(--cinza-texto)">${imovel.bairro}</span>
      </td>
      <td>${imovel.quartos} quartos · ${imovel.metragem} m²</td>
      <td><span class="badge ${badgeClass(imovel.status)}">${imovel.status}</span></td>
      <td>
        <span style="font-size: 18px">${imovel.destaque ? '⭐' : '—'}</span>
      </td>
      <td>
        <div class="action-btns">
          <button class="btn-icon btn-edit" title="Editar" onclick="openEdit(${imovel.id})">✏️</button>
          <button class="btn-icon btn-delete" title="Excluir" onclick="confirmDelete(${imovel.id})">🗑️</button>
        </div>
      </td>
    </tr>
  `).join('');
}

function badgeClass(status) {
  if (status === 'Lançamento') return 'badge-lancamento';
  if (status === 'Em Obras') return 'badge-obras';
  return 'badge-pronto';
}

// ============================================================
// BUSCA
// ============================================================

document.addEventListener('DOMContentLoaded', () => {
  const search = document.getElementById('search-imovel');
  if (search) {
    search.addEventListener('input', () => renderTable(search.value));
  }
});

// ============================================================
// MODAL - ABRIR/FECHAR
// ============================================================

function openModal(titulo, imovel = null) {
  editingId = imovel ? imovel.id : null;

  document.getElementById('modal-titulo').textContent = titulo;
  document.getElementById('modal-overlay').classList.add('open');

  // Preenche form
  const f = document.getElementById('form-imovel');
  if (imovel) {
    f.querySelector('[name="nome"]').value = imovel.nome || '';
    f.querySelector('[name="bairro"]').value = imovel.bairro || '';
    f.querySelector('[name="cidade"]').value = imovel.cidade || '';
    f.querySelector('[name="quartos"]').value = imovel.quartos || 2;
    f.querySelector('[name="metragem"]').value = imovel.metragem || '';
    f.querySelector('[name="descricao"]').value = imovel.descricao || '';
    f.querySelector('[name="tag"]').value = imovel.tag || 'Lançamento';
    f.querySelector('[name="status"]').value = imovel.status || 'Lançamento';
    f.querySelector('[name="imagem"]').value = imovel.imagem || '';
    f.querySelector('[name="localizacao"]').value = imovel.localizacao || '';
    f.querySelector('[name="mapsLink"]').value = imovel.mapsLink || '';
    f.querySelector('[name="destaque"]').checked = imovel.destaque || false;
    f.querySelector('[name="diferenciais"]').value = (imovel.diferenciais || []).join(', ');
  } else {
    f.reset();
  }

  updatePreview();
}

function closeModal() {
  document.getElementById('modal-overlay').classList.remove('open');
  editingId = null;
}

function openNovo() {
  openModal('Novo Imóvel');
}

function openEdit(id) {
  const imovel = appData.imoveis.find(i => i.id === id);
  if (imovel) openModal('Editar Imóvel', imovel);
}

// Fechar ao clicar fora
document.addEventListener('DOMContentLoaded', () => {
  const overlay = document.getElementById('modal-overlay');
  if (overlay) {
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) closeModal();
    });
  }
});

// ============================================================
// PREVIEW EM TEMPO REAL
// ============================================================

function updatePreview() {
  const f = document.getElementById('form-imovel');
  if (!f) return;

  const nome = f.querySelector('[name="nome"]').value || 'Nome do Imóvel';
  const bairro = f.querySelector('[name="bairro"]').value || 'Bairro';
  const quartos = f.querySelector('[name="quartos"]').value || '2';
  const metragem = f.querySelector('[name="metragem"]').value || '0';
  const imagem = f.querySelector('[name="imagem"]').value || 'https://via.placeholder.com/400x200?text=Sem+imagem';
  const tag = f.querySelector('[name="tag"]').value || 'Lançamento';
  const descricao = f.querySelector('[name="descricao"]').value || '';
  const destaque = f.querySelector('[name="destaque"]').checked;

  const prev = document.getElementById('card-preview');
  if (!prev) return;

  prev.innerHTML = `
    <div style="border-radius: 10px; overflow: hidden; box-shadow: 0 4px 16px rgba(0,0,0,0.1); background: white; max-width: 360px;">
      <div style="position: relative; height: 180px; overflow: hidden;">
        <img src="${imagem}" style="width:100%; height:100%; object-fit:cover;" 
          onerror="this.src='https://via.placeholder.com/400x200?text=URL+inválida'">
        <span style="position:absolute; top:10px; left:10px; background:#c0392b; color:white; font-size:11px; font-weight:700; padding:4px 10px; border-radius:20px; text-transform:uppercase;">${tag}</span>
        ${destaque ? '<span style="position:absolute; top:10px; right:10px; font-size:18px;">⭐</span>' : ''}
      </div>
      <div style="padding: 16px;">
        <p style="font-size:11px; color:#c0392b; font-weight:700; letter-spacing:1px; text-transform:uppercase; margin-bottom:4px;">Feira de Santana - Bahia</p>
        <h3 style="font-family: serif; font-size: 18px; color: #1a2a3a; margin-bottom: 10px;">${nome}</h3>
        <p style="font-size: 13px; color: #6b7280; margin-bottom: 12px; line-height: 1.5;">${descricao.slice(0, 100)}${descricao.length > 100 ? '...' : ''}</p>
        <div style="display:flex; gap:16px; padding:10px 0; border-top:1px solid #e5e8ec;">
          <span style="font-size:13px; color:#6b7280;">🛏️ ${quartos} Quartos</span>
          <span style="font-size:13px; color:#6b7280;">📐 ${metragem} m²</span>
        </div>
        <p style="font-size:12px; color:#6b7280; margin-top:8px;">📍 ${bairro}</p>
      </div>
    </div>
  `;
}

// Atualiza preview ao digitar
document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('form-imovel');
  if (form) {
    form.addEventListener('input', updatePreview);
    form.addEventListener('change', updatePreview);
  }
});

// ============================================================
// SALVAR IMÓVEL (CRUD)
// ============================================================

function salvarImovel() {
  const f = document.getElementById('form-imovel');
  if (!f) return;

  // Validação básica
  const nome = f.querySelector('[name="nome"]').value.trim();
  if (!nome) { showAdminToast('⚠️ O nome é obrigatório.', 'error'); return; }

  const novo = {
    id: editingId || (Math.max(0, ...appData.imoveis.map(i => i.id)) + 1),
    nome,
    bairro: f.querySelector('[name="bairro"]').value.trim(),
    cidade: f.querySelector('[name="cidade"]').value.trim() || 'Feira de Santana - Bahia',
    quartos: parseInt(f.querySelector('[name="quartos"]').value) || 2,
    metragem: f.querySelector('[name="metragem"]').value.trim(),
    descricao: f.querySelector('[name="descricao"]').value.trim(),
    tag: f.querySelector('[name="tag"]').value,
    status: f.querySelector('[name="status"]').value,
    imagem: f.querySelector('[name="imagem"]').value.trim(),
    imagemGaleria: [f.querySelector('[name="imagem"]').value.trim()],
    localizacao: f.querySelector('[name="localizacao"]').value.trim(),
    mapsLink: f.querySelector('[name="mapsLink"]').value.trim(),
    destaque: f.querySelector('[name="destaque"]').checked,
    diferenciais: f.querySelector('[name="diferenciais"]').value.split(',').map(s => s.trim()).filter(Boolean),
    plantas: []
  };

  if (editingId) {
    const idx = appData.imoveis.findIndex(i => i.id === editingId);
    if (idx > -1) {
      // Preserva campos que não estão no form
      appData.imoveis[idx] = { ...appData.imoveis[idx], ...novo };
    }
  } else {
    appData.imoveis.push(novo);
  }

  // Salva (simulado - ver integração backend)
  saveData();
  closeModal();
  renderDashboard();
  renderTable();
  showAdminToast(editingId ? '✅ Imóvel atualizado com sucesso!' : '✅ Imóvel criado com sucesso!');
}

// ============================================================
// EXCLUIR IMÓVEL
// ============================================================

function confirmDelete(id) {
  const imovel = appData.imoveis.find(i => i.id === id);
  if (!imovel) return;

  if (confirm(`Tem certeza que deseja excluir "${imovel.nome}"?\n\nEsta ação não pode ser desfeita.`)) {
    appData.imoveis = appData.imoveis.filter(i => i.id !== id);
    saveData();
    renderDashboard();
    renderTable();
    showAdminToast('🗑️ Imóvel excluído com sucesso.');
  }
}

// ============================================================
// SALVAR DADOS
// ============================================================

/**
 * saveData - Persiste os dados
 *
 * VERSÃO DEMO: Armazena no objeto em memória e mostra alerta
 * para o usuário copiar o JSON atualizado.
 *
 * PARA PRODUÇÃO - substituir por chamada ao backend:
 *
 * async function saveData() {
 *   const res = await fetch('/api/imoveis', {
 *     method: 'POST',
 *     headers: { 'Content-Type': 'application/json' },
 *     body: JSON.stringify(appData)
 *   });
 *   if (!res.ok) throw new Error('Erro ao salvar');
 * }
 *
 * Backend PHP simples (save.php):
 * <?php
 *   $data = file_get_contents('php://input');
 *   file_put_contents('../data/imoveis.json', $data);
 *   echo json_encode(['ok' => true]);
 * ?>
 */
async function saveData() {
  try {
    // Tenta salvar via API se disponível
    const res = await fetch('/api/save', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(appData)
    });
    if (res.ok) return;
  } catch (e) {
    // API não disponível - modo offline
  }

  // Fallback: mostra JSON para copiar
  console.log('📁 Dados atualizados (copie para imoveis.json):');
  console.log(JSON.stringify(appData, null, 2));
}

// ============================================================
// CONFIGURAÇÕES DO SITE
// ============================================================

function loadConfigForm() {
  const f = document.getElementById('form-config');
  if (!f || !appData.config) return;
  const c = appData.config;
  Object.keys(c).forEach(key => {
    const el = f.querySelector(`[name="${key}"]`);
    if (el) el.value = c[key];
  });
}

function salvarConfig() {
  const f = document.getElementById('form-config');
  if (!f) return;

  const inputs = f.querySelectorAll('input, textarea');
  inputs.forEach(input => {
    appData.config[input.name] = input.value;
  });

  saveData();
  showAdminToast('✅ Configurações salvas!');
}

// ============================================================
// EXPORTAR JSON
// ============================================================

function exportarJSON() {
  const blob = new Blob([JSON.stringify(appData, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'imoveis.json';
  a.click();
  URL.revokeObjectURL(url);
  showAdminToast('📥 JSON exportado! Substitua o arquivo data/imoveis.json');
}

// ============================================================
// IMPORTAR JSON
// ============================================================

function importarJSON() {
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = '.json';
  input.onchange = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const data = JSON.parse(ev.target.result);
        appData = data;
        renderDashboard();
        renderTable();
        loadConfigForm();
        showAdminToast('✅ JSON importado com sucesso!');
      } catch {
        showAdminToast('❌ Arquivo JSON inválido.', 'error');
      }
    };
    reader.readAsText(file);
  };
  input.click();
}

// ============================================================
// NAVEGAÇÃO SIDEBAR
// ============================================================

function showSection(sectionId) {
  document.querySelectorAll('.admin-section').forEach(s => s.style.display = 'none');
  const section = document.getElementById(`section-${sectionId}`);
  if (section) section.style.display = 'block';

  document.querySelectorAll('.sidebar-link').forEach(l => l.classList.remove('active'));
  const activeLink = document.querySelector(`[data-section="${sectionId}"]`);
  if (activeLink) activeLink.classList.add('active');

  if (sectionId === 'config') loadConfigForm();
}

// ============================================================
// TOAST ADMIN
// ============================================================

function showAdminToast(msg, type = 'success') {
  let toast = document.getElementById('admin-toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'admin-toast';
    toast.className = 'toast';
    document.body.appendChild(toast);
  }
  toast.className = `toast ${type}`;
  toast.textContent = msg;
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 4000);
}

// ============================================================
// INIT ADMIN
// ============================================================

document.addEventListener('DOMContentLoaded', () => {
  loadAdminData();
  showSection('imoveis');
});
